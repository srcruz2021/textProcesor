package format

import "fmt"

const (
	blankSpace = "" 
)

//interface in charge to translate from a text format to a binary format.
type BinaryTranslator interface {
	StringtoBynary(textValue string) (binary string, err error)
}

// Binary Implementation
type binaryImplementation struct {
	textSlice []string
}

// Binary constructor 
func NewBinaryImplementatio() BinaryTranslator {
	return &binaryImplementation{
		textSlice: []string{},
	}
}

// Binary implementation
func (b *binaryImplementation) StringtoBynary(textValue string) (binary string, err error) {
	 tempSlice := b.textProcessor(textValue)
	 b.textSlice = tempSlice
	return fmt.Sprintln(b.textSlice), nil
}

//function in charge of converting a character to binary
func StringToBinary(c string) (binString string) {
	for i, _ := range c {
		binString = fmt.Sprintf("%08b", byte(c[i]))
	}
	return binString
}

// function in charge of processing the different characters and returning a slice of text
func (b *binaryImplementation) textProcessor(text string) []string{
	stringSlice := []string{}
	for i := 0; i <= len(text)-1 ; i++ {
		caracter := StringToBinary(text)
		stringSlice = append(stringSlice, caracter)
		stringSlice = append(stringSlice, blankSpace)
	}
	return stringSlice
}
