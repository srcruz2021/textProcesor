package format

import (
	"reflect"
	"testing"
)

func TestNewBinaryImplementatio(t *testing.T) {
	tests := []struct {
		name string
		want BinaryTranslator
	}{
		{
			name: "TestNewIntanceOfBinaryImplementation",
			want: NewBinaryImplementatio(),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewBinaryImplementatio(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewBinaryImplementatio() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestStringToBinary(t *testing.T) {
	type args struct {
		c string
	}
	testArgs := args{
		c: "A",
	}
	tests := []struct {
		name          string
		args          args
		wantBinString string
	}{
		{
			name:          "SuccessExecution",
			args:          testArgs,
			wantBinString: "01000001",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotBinString := StringToBinary(tt.args.c); gotBinString != tt.wantBinString {
				t.Errorf("StringToBinary() = %v, want %v", gotBinString, tt.wantBinString)
			}
		})
	}
}

func Test_binaryImplementation_StringtoBynary(t *testing.T) {
	type fields struct {
		textSlice []string
	}
	type args struct {
		textValue string
	}

	mockTextSlice := []string{"01000001","01000001"}
	mockFields := fields{
		textSlice: mockTextSlice,
	}

	mockArgs := args{
		textValue: "AA",
	}

	mockResponse := "[01000001  01000001 ]\n"

	tests := []struct {
		name       string
		fields     fields
		args       args
		wantBinary string
		wantErr    bool
	}{
		{
			name:       "TestSuccessExecution_StringtoBynary",
			fields:     mockFields,
			args:       mockArgs,
			wantBinary: mockResponse,
			wantErr:    false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := &binaryImplementation{
				textSlice: tt.fields.textSlice,
			}
			gotBinary, err := b.StringtoBynary(tt.args.textValue)
			if (err != nil) != tt.wantErr {
				t.Errorf("StringtoBynary() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotBinary != tt.wantBinary {
				t.Errorf("StringtoBynary() gotBinary = %v, want %v", gotBinary, tt.wantBinary)
			}
		})
	}
}

func Test_binaryImplementation_textProcessor(t *testing.T) {
	type fields struct {
		textSlice []string
	}
	type args struct {
		text string
	}
	mockTextSlice := []string{"01000001","01000001"}
	mockFields := fields{
		textSlice: mockTextSlice,
	}

	mockResponse := []string{"01000001","","01000001",""}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   []string
	}{
		{
			name:   "TestTextProcessor",
			fields: mockFields,
			args:   args{
				text: "AA",
			},
			want:   mockResponse,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := &binaryImplementation{
				textSlice: tt.fields.textSlice,
			}
			if got := b.textProcessor(tt.args.text); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("textProcessor() = %v, want %v", got, tt.want)
			}
		})
	}
}