package main

import (
	"fmt"
	"text-translator/format"
)

func main() {
	// Se debe implementar un Factory para elegir que implementacion usar, en base a la selección.
	binaryImp := format.NewBinaryImplementatio()

	value, _ := binaryImp.StringtoBynary("AB")
	fmt.Println(value)
	value2, _ := binaryImp.StringtoBynary("B")
	fmt.Println(value2)


}
